import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart';

import 'connect.dart';
import 'login.dart';

class Reg extends StatefulWidget {
  const Reg({Key? key}) : super(key: key);

  @override
  State<Reg> createState() => _RegState();
}

class _RegState extends State<Reg> {
  var email = TextEditingController();
  var password = TextEditingController();
  var confirmpassword = TextEditingController();

  Future<void> getData() async {
    var data = {
      "email": email.text,
      "password": password.text,
      "confirmpassword": confirmpassword.text,
    };
    var response = await post(Uri.parse('${Con.url}register.php'), body: data);
    print(response.body);
    if (response.statusCode == 200) {
      var res = jsonDecode(response.body)["result"];
      if (res == 'success') {
        const snackBar = SnackBar(
          content: Text("successfully registered"),
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) {
            return const Login();
          }),
        );
      }
    } else {
      Fluttertoast.showToast(msg: "something went wrong");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assesst/068tpapjuryw52vy.jpg"),
                fit: BoxFit.cover, // Fit the image to fullscreen
              ),
            ),
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(40.0),
                child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(100.0),
                        child: const Text(
                          'TODO',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 28,
                            fontFamily: 'railway',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 100,
                        width: 100,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: TextField(
                          controller: email,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            labelText: "Email",
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: TextField(
                          controller: password,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            labelText: "Password",
                            suffixIcon: IconButton(
                              icon: const Icon(Icons.remove_red_eye_rounded),
                              onPressed: () {},
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: TextField(
                          controller: confirmpassword,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            labelText: "Confirm Password",
                            suffixIcon: IconButton(
                              icon: const Icon(Icons.remove_red_eye_rounded),
                              onPressed: () {},
                            ),
                          ),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(
                          left: 20,
                        ),
                        // child: Text(
                        //   "forgot password?",
                        //   style: TextStyle(
                        //     color: Colors.grey,
                        //     fontSize: 12,
                        //     fontFamily: 'railway',
                        //     fontWeight: FontWeight.bold,
                        //   ),
                        // ),
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      SizedBox(
                        width: 350.0,
                        height: 50.0,
                        child: ElevatedButton(
                          onPressed: (){
                            getData();
                          },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green.shade700),
                          child: const Text('register'),
                        ),
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.facebook),
                          Icon(Icons.g_mobiledata_outlined),

                        ],
                      ),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children:[
                            const Text('you already have an account?'),
                            TextButton(onPressed:(){


                            },
                                child: const Text("Sign in.")),
                          ]
                      ),

                    ]
                ),
              ),
            )
        )
    );
  }
}
