import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';

import 'connect.dart';
import 'mytask2.dart';

class Edittask extends StatefulWidget {
  Edittask({super.key, required this.id});
  var id;
  @override
  State<Edittask> createState() => _EdittaskState();
}

class _EdittaskState extends State<Edittask> {
  TextEditingController taskname = TextEditingController();
  TextEditingController time = TextEditingController();

  Future<dynamic> updaterecord() async {
    var data = {"task_name": taskname.text, "time": time.text, "id": widget.id};
    print(data);
    var response = await post(Uri.parse('${Con.url}edittask.php'), body: data);
    print(response.body);
    var res = jsonDecode(response.body)["update"];
    if (res == 'success') {
      const snackBar = SnackBar(
        content: Text("task edited"),
      );
      Navigator.push(context, MaterialPageRoute(
        builder: (context) {
          return Task2(id: widget.id);
        },
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Edit Task"),
          centerTitle: true,
          backgroundColor: Colors.indigo.shade900,
          actions: const [
            Icon(
              Icons.doorbell_outlined,
              color: Colors.white,
            ),
          ],
          leading: const Icon(
            Icons.horizontal_split,
            color: Colors.white,
          ),
        ),
        body: Column(children: <Widget>[
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Text(
                "Task name",
                style: TextStyle(
                    color: Colors.indigo.shade900,
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: TextField(
              controller: taskname,
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(0),
                ),
                labelText: "Name",
                hintText: "UI Design",
              ),
            ),
          ),
          Row(
            children: [
              Text(
                "Date & Time",
                style: TextStyle(
                    color: Colors.indigo.shade900,
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              controller: time,
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(0),
                ),
                labelText: "Name",
                hintText: "01 March Monday",
                suffixIcon: IconButton(
                  icon: const Icon(Icons.calendar_month),
                  onPressed: () {},
                ),
              ),
            ),
          ),
          SizedBox(
            width: 300.0,
            height: 50.0,
            child: ElevatedButton(
              onPressed: () {
                updaterecord();
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade700),
              child: const Text('Edit Done'),
            ),
          ),
        ]));
  }
}
