import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'connect.dart';
import 'cretetask.dart';
import 'edittask.dart';
import 'profile.dart';

class Home extends StatefulWidget {
  Home({Key? key, required this.id}) : super(key: key);
  var id;

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Future<dynamic> getData() async {
    var data = {"id": widget.id};
    print(data);
    var response = await http.post(Uri.parse('${Con.url}viewtask.php'), body: data);
    print('-----${response.body}');

    return jsonDecode(response.body);
  }

  List userdata = [];
  Future<void> delete(String id) async {
    var response = await http.post(Uri.parse('${Con.url}deletetask.php'), body: {'id': id});
    print(',,,,,${response.body}');
    if (response.statusCode == 200) {
      var res = jsonDecode(response.body)["delete"];
      if (res == 'success') {
        print("Task deleted");
      }
      getData();
    } else {
      print("Some issue");
    }
  }

  void logout() {
    SystemChannels.platform.invokeMethod('SystemNavigator.pop');
  }

  // void navigateToProfile() {
  //   Navigator.push(
  //     context,
  //     MaterialPageRoute(
  //       builder: (context) => Viewpro(),
  //     ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home Page"),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: FloatingActionButton(
              onPressed: logout,
              child: Icon(Icons.power_settings_new_rounded),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home_outlined,
              color: Colors.black,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.calendar_month,
              color: Colors.black,
            ),
            label: 'Calender',
          ),
          // BottomNavigationBarItem(
          //   icon: Icon(
          //     Icons.person_outline,
          //     color: Colors.black,
          //   ),
          //   label: 'Profile',
          // ),
        ],
        // onTap: (index) {
        //   if (index == 1) {
        //     navigateToProfile();
        //   }
        // },
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assesst/bg.jpeg"),
            fit: BoxFit.cover,
          ),
        ),
        child: FutureBuilder(
          future: getData(),
          builder: (context, snapshot) {
            if (snapshot.hasError) print('Error: ${snapshot.error}');
            print('View task: ${snapshot.hasData}');
            if (!snapshot.hasData) {
              return const Center(
                child: Text('No Data..'),
              );
            }
            return ListView.builder(
              itemCount: snapshot.data.length,
              itemBuilder: (context, index) {
                return Card(
                  child: ListTile(
                    title: Text(snapshot.data![index]['task_name']),
                    subtitle: Text(snapshot.data![index]['time']),
                    leading: const Icon(
                      Icons.schedule_outlined,
                      color: Colors.indigo,
                    ),
                    trailing: Wrap(
                      spacing: 12,
                      children: [
                        IconButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) {
                                  return Edittask(id: widget.id);
                                },
                              ),
                            );
                          },
                          icon: const Icon(
                            Icons.edit,
                            color: Colors.indigo,
                          ),
                        ),
                        IconButton(
                          onPressed: () {
                            delete(snapshot.data![index]['task_id']);
                          },
                          icon: const Icon(
                            Icons.delete,
                            color: Colors.indigo,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Createtask(
                id: widget.id,
              ),
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}