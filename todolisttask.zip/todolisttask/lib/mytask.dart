import 'package:flutter/material.dart';

class Mytask extends StatefulWidget {
  const Mytask({Key? key}) : super(key: key);

  @override
  State<Mytask> createState() => _MytaskState();
}

class _MytaskState extends State<Mytask> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Task"),
        centerTitle: true,
        backgroundColor: Colors.indigo,
        actions: const [
          Icon(
            Icons.doorbell_outlined,
            color: Colors.white,
          ),
        ],
        leading: const Icon(
          Icons.horizontal_split,
          color: Colors.white,
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(items: const [
        BottomNavigationBarItem(
            icon: Icon(
              Icons.home_outlined,
              color: Colors.black,
            ),
            label: 'home'),
        BottomNavigationBarItem(
            icon: Icon(
              Icons.calendar_month_outlined,
              color: Colors.black,
            ),
            label: 'calender'),
        BottomNavigationBarItem(
            icon: Icon(Icons.messenger_outline, color: Colors.black),
            label: 'message'),
      ]),
      body: ListView(children: [
        Card(
          child: ListTile(
            title: const Text("Ui Design"),
            subtitle: const Text("09:00 AM-11:00 AM"),
            leading: const Icon(
              Icons.schedule_outlined,
              color: Colors.indigo,
            ),
            trailing: const Wrap(
              spacing: 12,
              children: [
                Icon(
                  Icons.edit,
                  color: Colors.indigo,
                ),
                Icon(
                  Icons.delete,
                  color: Colors.indigo,
                ),
              ],
            ),
            onTap: () {},
          ),
        ),
        const Card(
            child: ListTile(
          title: Text("Ui Design"),
          subtitle: Text("09:00 AM-11:00 AM"),
          leading: Icon(
            Icons.schedule_outlined,
            color: Colors.indigo,
          ),
          trailing: Wrap(
            spacing: 12,
            children: [
              Icon(
                Icons.edit,
                color: Colors.indigo,
              ),
              Icon(
                Icons.delete,
                color: Colors.indigo,
              ),
            ],
          ),
        )),
        const Card(
            child: ListTile(
          title: Text("Ui Design"),
          subtitle: Text("09:00 AM-11:00 AM"),
          leading: Icon(
            Icons.schedule_outlined,
            color: Colors.indigo,
          ),
          trailing: Wrap(
            spacing: 12,
            children: [
              Icon(
                Icons.edit,
                color: Colors.indigo,
              ),
              Icon(
                Icons.delete,
                color: Colors.indigo,
              ),
            ],
          ),
        )),
        const Card(
            child: ListTile(
          title: Text("Ui Design"),
          subtitle: Text("09:00 AM-11:00 AM"),
          leading: Icon(
            Icons.schedule_outlined,
            color: Colors.indigo,
          ),
          trailing: Wrap(
            spacing: 12,
            children: [
              Icon(
                Icons.edit,
                color: Colors.indigo,
              ),
              Icon(
                Icons.delete,
                color: Colors.indigo,
              ),
            ],
          ),
        )),
        const Card(
            child: ListTile(
          title: Text("Ui Design"),
          subtitle: Text("09:00 AM-11:00 AM"),
          leading: Icon(
            Icons.schedule_outlined,
            color: Colors.indigo,
          ),
          trailing: Wrap(
            spacing: 12,
            children: [
              Icon(
                Icons.edit,
                color: Colors.indigo,
              ),
              Icon(
                Icons.delete,
                color: Colors.indigo,
              ),
            ],
          ),
        )),
        const Card(
            child: ListTile(
          title: Text("Ui Design"),
          subtitle: Text("09:00 AM-11:00 AM"),
          leading: Icon(
            Icons.schedule_outlined,
            color: Colors.indigo,
          ),
          trailing: Wrap(
            spacing: 12,
            children: [
              Icon(
                Icons.edit,
                color: Colors.indigo,
              ),
              Icon(
                Icons.delete,
                color: Colors.indigo,
              ),
            ],
          ),
        )),
        const Card(
            child: ListTile(
          title: Text("Ui Design"),
          subtitle: Text("09:00 AM-11:00 AM"),
          leading: Icon(
            Icons.schedule_outlined,
            color: Colors.indigo,
          ),
          trailing: Wrap(
            spacing: 12,
            children: [
              Icon(
                Icons.edit,
                color: Colors.indigo,
              ),
              Icon(
                Icons.delete,
                color: Colors.indigo,
              ),
            ],
          ),
        )),
        const SizedBox(
          height: 20,
        ),
        const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.add_circle,
              color: Colors.indigo,
              size: 40,
            )
          ],
        )
      ]),
    );
  }
}
