import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';

import 'connect.dart';
import 'mytask2.dart';

class Createtask extends StatefulWidget {
  Createtask({Key? key, required this.id}) : super(key: key);
  var id;

  @override
  State<Createtask> createState() => _CreatetaskState();
}

class _CreatetaskState extends State<Createtask> {
  var taskname = TextEditingController();
  var time = TextEditingController();

  Future<void> sendData() async {
    var data = {"task_name": taskname.text, "time": time.text, "id": widget.id};
    print(data);

    var response = await post(Uri.parse('${Con.url}addtask.php'), body: data);
    print(response.body);
    var res = jsonDecode(response.body);
    print(widget.id);
    print(response.statusCode);
    if (jsonDecode(response.body)['result'] == 'success') {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Create task successfully..')));
      // Navigator.pop(context);
      Navigator.push(context, MaterialPageRoute(
        builder: (context) {
          return Task2(id: widget.id);
        },
      ));

      // }
      // else
      //   ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to Transfer the amount..')));
      // Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Task"),
        centerTitle: true,
        backgroundColor: Colors.indigo.shade900,
        actions: const [
          Icon(
            Icons.doorbell_outlined,
            color: Colors.white,
          ),
        ],
        leading: const Icon(
          Icons.horizontal_split,
          color: Colors.white,
        ),
      ),
      body: Column(children: <Widget>[
        const SizedBox(
          height: 10,
        ),
        Row(
          children: [
            Text(
              "Task name",
              style: TextStyle(
                  color: Colors.indigo.shade900,
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: TextField(
            controller: taskname,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(0),
              ),
              labelText: "Name",
              hintText: "UI Design",
            ),
          ),
        ),
        Row(
          children: [
            Text(
              "Date & Time",
              style: TextStyle(
                  color: Colors.indigo.shade900,
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: TextField(
            controller: time,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(0),
              ),
              labelText: "Name",
              hintText: "01 March Monday",
              suffixIcon: IconButton(
                icon: const Icon(Icons.calendar_month),
                onPressed: () {},
              ),
            ),
          ),
        ),
        ElevatedButton(
            onPressed: () {
              sendData();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade700),
            child: const Text("Create Task")),
      ]),
    );
  }
}
