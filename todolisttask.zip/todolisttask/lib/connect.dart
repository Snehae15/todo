class Con{
  static const url="http://192.168.76.245/todo/";
}