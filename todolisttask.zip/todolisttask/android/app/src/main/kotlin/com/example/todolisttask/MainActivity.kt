package com.example.todolisttask

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
