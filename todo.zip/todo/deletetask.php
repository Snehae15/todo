<?php
include 'connect.php';
$id = $_POST['id'];
$sql = mysqli_query($con,"DELETE FROM task where task_id ='$id'");
if ($sql){
    $my['delete'] = 'success';
   
}else{
    $my['delete'] = 'failed';
}
echo json_encode($my);

