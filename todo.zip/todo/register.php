<?php
include 'connect.php';
$email = $_POST['email'];
$password = $_POST['password'];
$confirmpassword = $_POST['confirmpassword'];
$sql = mysqli_query($con,"INSERT INTO register(email,password,confirmpassword)values('$email','$password','$confirmpassword')");
if ($sql){
    $my['result'] = 'success';
   
}else{
    $my['result'] = 'failed';
}
echo json_encode($my);