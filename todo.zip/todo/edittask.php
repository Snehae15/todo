<?php
include 'connect.php';
$id = $_POST['id'];

$tk = $_POST['task_name'];
$tme = $_POST['time'];

$sql = mysqli_query($con,"UPDATE task SET task_name ='$tk',time ='$tme' where task_id ='$id'");
if($sql){
    $my['update'] = 'success';
   
}else{
    $my['result'] = 'failed';
}
echo json_encode($my);

