<?php
include 'connect.php';
//$id=$_POST['id'];
$sql=mysqli_query($con,"SELECT * FROM task");
$list=array();

if($sql->num_rows>0){
    while($row=mysqli_fetch_assoc($sql)){
        
        $myarray['message']= 'viewed';
        $myarray['task_id']=$row['task_id'];
        $myarray['task_name']=$row['task_name'];
        $myarray['time']=$row['time'];
    
    array_push($list,$myarray);
    
    }
}else{
    $myarray['message']='failed';
    array_push($list,$myarray);
}
echo json_encode($list);
?>