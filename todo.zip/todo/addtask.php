<?php
include 'connect.php';
$tk = $_POST['task_name'];
$tme = $_POST['time'];

$sql = mysqli_query($con,"INSERT INTO task(task_name,time)values('$tk','$tme')");
if ($sql){
    $my['result'] = 'success';
   
}else{
    $my['result'] = 'failed';
}
echo json_encode($my);

