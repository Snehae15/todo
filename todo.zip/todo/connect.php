<?php
$con=new mysqli('localhost','root','','todo');
// if($conn){
//     echo "success";
// }
// else{
//     echo "fail";
// }
?>